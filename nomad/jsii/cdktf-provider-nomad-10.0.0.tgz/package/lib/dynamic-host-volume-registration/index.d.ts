/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DynamicHostVolumeRegistrationConfig extends cdktf.TerraformMetaArguments {
    /**
    * Provisioned capacity
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.0/docs/resources/dynamic_host_volume_registration#capacity DynamicHostVolumeRegistration#capacity}
    */
    readonly capacity?: string;
    /**
    * Host path
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.0/docs/resources/dynamic_host_volume_registration#host_path DynamicHostVolumeRegistration#host_path}
    */
    readonly hostPath: string;
    /**
    * Volume name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.0/docs/resources/dynamic_host_volume_registration#name DynamicHostVolumeRegistration#name}
    */
    readonly name: string;
    /**
    * Volume namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.0/docs/resources/dynamic_host_volume_registration#namespace DynamicHostVolumeRegistration#namespace}
    */
    readonly namespace?: string;
    /**
    * Node ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.0/docs/resources/dynamic_host_volume_registration#node_id DynamicHostVolumeRegistration#node_id}
    */
    readonly nodeId: string;
    /**
    * Parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.0/docs/resources/dynamic_host_volume_registration#parameters DynamicHostVolumeRegistration#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * capability block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.0/docs/resources/dynamic_host_volume_registration#capability DynamicHostVolumeRegistration#capability}
    */
    readonly capability: DynamicHostVolumeRegistrationCapability[] | cdktf.IResolvable;
}
export interface DynamicHostVolumeRegistrationConstraint {
}
export declare function dynamicHostVolumeRegistrationConstraintToTerraform(struct?: DynamicHostVolumeRegistrationConstraint): any;
export declare function dynamicHostVolumeRegistrationConstraintToHclTerraform(struct?: DynamicHostVolumeRegistrationConstraint): any;
export declare class DynamicHostVolumeRegistrationConstraintOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DynamicHostVolumeRegistrationConstraint | undefined;
    set internalValue(value: DynamicHostVolumeRegistrationConstraint | undefined);
    get attribute(): string;
    get operator(): string;
    get value(): string;
}
export declare class DynamicHostVolumeRegistrationConstraintList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DynamicHostVolumeRegistrationConstraintOutputReference;
}
export interface DynamicHostVolumeRegistrationCapability {
    /**
    * An access mode available for the volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.0/docs/resources/dynamic_host_volume_registration#access_mode DynamicHostVolumeRegistration#access_mode}
    */
    readonly accessMode: string;
    /**
    * An attachment mode available for the volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.0/docs/resources/dynamic_host_volume_registration#attachment_mode DynamicHostVolumeRegistration#attachment_mode}
    */
    readonly attachmentMode: string;
}
export declare function dynamicHostVolumeRegistrationCapabilityToTerraform(struct?: DynamicHostVolumeRegistrationCapability | cdktf.IResolvable): any;
export declare function dynamicHostVolumeRegistrationCapabilityToHclTerraform(struct?: DynamicHostVolumeRegistrationCapability | cdktf.IResolvable): any;
export declare class DynamicHostVolumeRegistrationCapabilityOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DynamicHostVolumeRegistrationCapability | cdktf.IResolvable | undefined;
    set internalValue(value: DynamicHostVolumeRegistrationCapability | cdktf.IResolvable | undefined);
    private _accessMode?;
    get accessMode(): string;
    set accessMode(value: string);
    get accessModeInput(): string | undefined;
    private _attachmentMode?;
    get attachmentMode(): string;
    set attachmentMode(value: string);
    get attachmentModeInput(): string | undefined;
}
export declare class DynamicHostVolumeRegistrationCapabilityList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DynamicHostVolumeRegistrationCapability[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DynamicHostVolumeRegistrationCapabilityOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.0/docs/resources/dynamic_host_volume_registration nomad_dynamic_host_volume_registration}
*/
export declare class DynamicHostVolumeRegistration extends cdktf.TerraformResource {
    static readonly tfResourceType = "nomad_dynamic_host_volume_registration";
    /**
    * Generates CDKTF code for importing a DynamicHostVolumeRegistration resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DynamicHostVolumeRegistration to import
    * @param importFromId The id of the existing DynamicHostVolumeRegistration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.0/docs/resources/dynamic_host_volume_registration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DynamicHostVolumeRegistration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.0/docs/resources/dynamic_host_volume_registration nomad_dynamic_host_volume_registration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DynamicHostVolumeRegistrationConfig
    */
    constructor(scope: Construct, id: string, config: DynamicHostVolumeRegistrationConfig);
    private _capacity?;
    get capacity(): string;
    set capacity(value: string);
    resetCapacity(): void;
    get capacityInput(): string | undefined;
    get capacityBytes(): number;
    get capacityMaxBytes(): number;
    get capacityMinBytes(): number;
    private _constraint;
    get constraint(): DynamicHostVolumeRegistrationConstraintList;
    private _hostPath?;
    get hostPath(): string;
    set hostPath(value: string);
    get hostPathInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _nodeId?;
    get nodeId(): string;
    set nodeId(value: string);
    get nodeIdInput(): string | undefined;
    get nodePool(): string;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    get pluginId(): string;
    get state(): string;
    private _capability;
    get capability(): DynamicHostVolumeRegistrationCapabilityList;
    putCapability(value: DynamicHostVolumeRegistrationCapability[] | cdktf.IResolvable): void;
    get capabilityInput(): cdktf.IResolvable | DynamicHostVolumeRegistrationCapability[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
