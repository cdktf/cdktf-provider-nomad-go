/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AclAuthMethodConfig extends cdktf.TerraformMetaArguments {
    /**
    * Defines whether this ACL Auth Method is to be set as default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#default AclAuthMethod#default}
    */
    readonly default?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#id AclAuthMethod#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Defines the maximum life of a token created by this method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#max_token_ttl AclAuthMethod#max_token_ttl}
    */
    readonly maxTokenTtl: string;
    /**
    * The identifier of the ACL Auth Method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#name AclAuthMethod#name}
    */
    readonly name: string;
    /**
    * Defines whether the ACL Auth Method creates a local or global token when performing SSO login. This field must be set to either "local" or "global".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#token_locality AclAuthMethod#token_locality}
    */
    readonly tokenLocality: string;
    /**
    * Defines the token format for the authenticated users. This can be lightly templated using HIL '${foo}' syntax.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#token_name_format AclAuthMethod#token_name_format}
    */
    readonly tokenNameFormat?: string;
    /**
    * ACL Auth Method SSO workflow type. Currently, the only supported type is "OIDC."
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#type AclAuthMethod#type}
    */
    readonly type: string;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#config AclAuthMethod#config}
    */
    readonly config: AclAuthMethodConfigA;
}
export interface AclAuthMethodConfigOidcClientAssertionPrivateKey {
    /**
    * Specific 'kid' header to set on the JWT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#key_id AclAuthMethod#key_id}
    */
    readonly keyId?: string;
    /**
    * Name of the header the IDP will use to find the cert to verify the JWT signature.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#key_id_header AclAuthMethod#key_id_header}
    */
    readonly keyIdHeader?: string;
    /**
    * An x509 certificate PEM to derive a key ID header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#pem_cert AclAuthMethod#pem_cert}
    */
    readonly pemCert?: string;
    /**
    * Path to an x509 certificate PEM on Nomad servers to derive a key ID header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#pem_cert_file AclAuthMethod#pem_cert_file}
    */
    readonly pemCertFile?: string;
    /**
    * RSA private key PEM to use to sign the JWT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#pem_key AclAuthMethod#pem_key}
    */
    readonly pemKey?: string;
    /**
    * Path to an RSA private key PEM on Nomad servers to use to sign the JWT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#pem_key_file AclAuthMethod#pem_key_file}
    */
    readonly pemKeyFile?: string;
}
export declare function aclAuthMethodConfigOidcClientAssertionPrivateKeyToTerraform(struct?: AclAuthMethodConfigOidcClientAssertionPrivateKeyOutputReference | AclAuthMethodConfigOidcClientAssertionPrivateKey): any;
export declare function aclAuthMethodConfigOidcClientAssertionPrivateKeyToHclTerraform(struct?: AclAuthMethodConfigOidcClientAssertionPrivateKeyOutputReference | AclAuthMethodConfigOidcClientAssertionPrivateKey): any;
export declare class AclAuthMethodConfigOidcClientAssertionPrivateKeyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AclAuthMethodConfigOidcClientAssertionPrivateKey | undefined;
    set internalValue(value: AclAuthMethodConfigOidcClientAssertionPrivateKey | undefined);
    private _keyId?;
    get keyId(): string;
    set keyId(value: string);
    resetKeyId(): void;
    get keyIdInput(): string | undefined;
    private _keyIdHeader?;
    get keyIdHeader(): string;
    set keyIdHeader(value: string);
    resetKeyIdHeader(): void;
    get keyIdHeaderInput(): string | undefined;
    private _pemCert?;
    get pemCert(): string;
    set pemCert(value: string);
    resetPemCert(): void;
    get pemCertInput(): string | undefined;
    private _pemCertFile?;
    get pemCertFile(): string;
    set pemCertFile(value: string);
    resetPemCertFile(): void;
    get pemCertFileInput(): string | undefined;
    private _pemKey?;
    get pemKey(): string;
    set pemKey(value: string);
    resetPemKey(): void;
    get pemKeyInput(): string | undefined;
    private _pemKeyFile?;
    get pemKeyFile(): string;
    set pemKeyFile(value: string);
    resetPemKeyFile(): void;
    get pemKeyFileInput(): string | undefined;
}
export interface AclAuthMethodConfigOidcClientAssertion {
    /**
    * List of audiences to accept the JWT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#audience AclAuthMethod#audience}
    */
    readonly audience?: string[];
    /**
    * Additional headers to include on the JWT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#extra_headers AclAuthMethod#extra_headers}
    */
    readonly extraHeaders?: {
        [key: string]: string;
    };
    /**
    * Algorithm of the key used to sign the JWT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#key_algorithm AclAuthMethod#key_algorithm}
    */
    readonly keyAlgorithm?: string;
    /**
    * The source of the key Nomad will use to sign the JWT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#key_source AclAuthMethod#key_source}
    */
    readonly keySource: string;
    /**
    * private_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#private_key AclAuthMethod#private_key}
    */
    readonly privateKey?: AclAuthMethodConfigOidcClientAssertionPrivateKey;
}
export declare function aclAuthMethodConfigOidcClientAssertionToTerraform(struct?: AclAuthMethodConfigOidcClientAssertionOutputReference | AclAuthMethodConfigOidcClientAssertion): any;
export declare function aclAuthMethodConfigOidcClientAssertionToHclTerraform(struct?: AclAuthMethodConfigOidcClientAssertionOutputReference | AclAuthMethodConfigOidcClientAssertion): any;
export declare class AclAuthMethodConfigOidcClientAssertionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AclAuthMethodConfigOidcClientAssertion | undefined;
    set internalValue(value: AclAuthMethodConfigOidcClientAssertion | undefined);
    private _audience?;
    get audience(): string[];
    set audience(value: string[]);
    resetAudience(): void;
    get audienceInput(): string[] | undefined;
    private _extraHeaders?;
    get extraHeaders(): {
        [key: string]: string;
    };
    set extraHeaders(value: {
        [key: string]: string;
    });
    resetExtraHeaders(): void;
    get extraHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _keyAlgorithm?;
    get keyAlgorithm(): string;
    set keyAlgorithm(value: string);
    resetKeyAlgorithm(): void;
    get keyAlgorithmInput(): string | undefined;
    private _keySource?;
    get keySource(): string;
    set keySource(value: string);
    get keySourceInput(): string | undefined;
    private _privateKey;
    get privateKey(): AclAuthMethodConfigOidcClientAssertionPrivateKeyOutputReference;
    putPrivateKey(value: AclAuthMethodConfigOidcClientAssertionPrivateKey): void;
    resetPrivateKey(): void;
    get privateKeyInput(): AclAuthMethodConfigOidcClientAssertionPrivateKey | undefined;
}
export interface AclAuthMethodConfigA {
    /**
    * A list of allowed values that can be used for the redirect URI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#allowed_redirect_uris AclAuthMethod#allowed_redirect_uris}
    */
    readonly allowedRedirectUris?: string[];
    /**
    * List of auth claims that are valid for login.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#bound_audiences AclAuthMethod#bound_audiences}
    */
    readonly boundAudiences?: string[];
    /**
    * The value against which to match the iss claim in a JWT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#bound_issuer AclAuthMethod#bound_issuer}
    */
    readonly boundIssuer?: string[];
    /**
    * Mappings of claims (key) that will be copied to a metadata field (value).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#claim_mappings AclAuthMethod#claim_mappings}
    */
    readonly claimMappings?: {
        [key: string]: string;
    };
    /**
    * Duration of leeway when validating all claims in the form of a time duration such as "5m" or "1h".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#clock_skew_leeway AclAuthMethod#clock_skew_leeway}
    */
    readonly clockSkewLeeway?: string;
    /**
    * PEM encoded CA certs for use by the TLS client used to talk with the OIDC Discovery URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#discovery_ca_pem AclAuthMethod#discovery_ca_pem}
    */
    readonly discoveryCaPem?: string[];
    /**
    * Duration of leeway when validating expiration of a JWT in the form of a time duration such as "5m" or "1h".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#expiration_leeway AclAuthMethod#expiration_leeway}
    */
    readonly expirationLeeway?: string;
    /**
    * PEM encoded CA cert for use by the TLS client used to talk with the JWKS server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#jwks_ca_cert AclAuthMethod#jwks_ca_cert}
    */
    readonly jwksCaCert?: string;
    /**
    * JSON Web Key Sets url for authenticating signatures.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#jwks_url AclAuthMethod#jwks_url}
    */
    readonly jwksUrl?: string;
    /**
    * List of PEM-encoded public keys to use to authenticate signatures locally.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#jwt_validation_pub_keys AclAuthMethod#jwt_validation_pub_keys}
    */
    readonly jwtValidationPubKeys?: string[];
    /**
    * Mappings of list claims (key) that will be copied to a metadata field (value).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#list_claim_mappings AclAuthMethod#list_claim_mappings}
    */
    readonly listClaimMappings?: {
        [key: string]: string;
    };
    /**
    * Duration of leeway when validating not before values of a token in the form of a time duration such as "5m" or "1h".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#not_before_leeway AclAuthMethod#not_before_leeway}
    */
    readonly notBeforeLeeway?: string;
    /**
    * The OAuth Client ID configured with the OIDC provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#oidc_client_id AclAuthMethod#oidc_client_id}
    */
    readonly oidcClientId?: string;
    /**
    * The OAuth Client Secret configured with the OIDC provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#oidc_client_secret AclAuthMethod#oidc_client_secret}
    */
    readonly oidcClientSecret?: string;
    /**
    * Nomad will not make a request to the identity provider to get OIDC UserInfo.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#oidc_disable_userinfo AclAuthMethod#oidc_disable_userinfo}
    */
    readonly oidcDisableUserinfo?: boolean | cdktf.IResolvable;
    /**
    * The OIDC Discovery URL, without any .well-known component (base path).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#oidc_discovery_url AclAuthMethod#oidc_discovery_url}
    */
    readonly oidcDiscoveryUrl?: string;
    /**
    * Nomad include PKCE challenge in OIDC auth requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#oidc_enable_pkce AclAuthMethod#oidc_enable_pkce}
    */
    readonly oidcEnablePkce?: boolean | cdktf.IResolvable;
    /**
    * List of OIDC scopes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#oidc_scopes AclAuthMethod#oidc_scopes}
    */
    readonly oidcScopes?: string[];
    /**
    * A list of supported signing algorithms.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#signing_algs AclAuthMethod#signing_algs}
    */
    readonly signingAlgs?: string[];
    /**
    * Enable OIDC verbose logging on the Nomad server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#verbose_logging AclAuthMethod#verbose_logging}
    */
    readonly verboseLogging?: boolean | cdktf.IResolvable;
    /**
    * oidc_client_assertion block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#oidc_client_assertion AclAuthMethod#oidc_client_assertion}
    */
    readonly oidcClientAssertion?: AclAuthMethodConfigOidcClientAssertion;
}
export declare function aclAuthMethodConfigAToTerraform(struct?: AclAuthMethodConfigAOutputReference | AclAuthMethodConfigA): any;
export declare function aclAuthMethodConfigAToHclTerraform(struct?: AclAuthMethodConfigAOutputReference | AclAuthMethodConfigA): any;
export declare class AclAuthMethodConfigAOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AclAuthMethodConfigA | undefined;
    set internalValue(value: AclAuthMethodConfigA | undefined);
    private _allowedRedirectUris?;
    get allowedRedirectUris(): string[];
    set allowedRedirectUris(value: string[]);
    resetAllowedRedirectUris(): void;
    get allowedRedirectUrisInput(): string[] | undefined;
    private _boundAudiences?;
    get boundAudiences(): string[];
    set boundAudiences(value: string[]);
    resetBoundAudiences(): void;
    get boundAudiencesInput(): string[] | undefined;
    private _boundIssuer?;
    get boundIssuer(): string[];
    set boundIssuer(value: string[]);
    resetBoundIssuer(): void;
    get boundIssuerInput(): string[] | undefined;
    private _claimMappings?;
    get claimMappings(): {
        [key: string]: string;
    };
    set claimMappings(value: {
        [key: string]: string;
    });
    resetClaimMappings(): void;
    get claimMappingsInput(): {
        [key: string]: string;
    } | undefined;
    private _clockSkewLeeway?;
    get clockSkewLeeway(): string;
    set clockSkewLeeway(value: string);
    resetClockSkewLeeway(): void;
    get clockSkewLeewayInput(): string | undefined;
    private _discoveryCaPem?;
    get discoveryCaPem(): string[];
    set discoveryCaPem(value: string[]);
    resetDiscoveryCaPem(): void;
    get discoveryCaPemInput(): string[] | undefined;
    private _expirationLeeway?;
    get expirationLeeway(): string;
    set expirationLeeway(value: string);
    resetExpirationLeeway(): void;
    get expirationLeewayInput(): string | undefined;
    private _jwksCaCert?;
    get jwksCaCert(): string;
    set jwksCaCert(value: string);
    resetJwksCaCert(): void;
    get jwksCaCertInput(): string | undefined;
    private _jwksUrl?;
    get jwksUrl(): string;
    set jwksUrl(value: string);
    resetJwksUrl(): void;
    get jwksUrlInput(): string | undefined;
    private _jwtValidationPubKeys?;
    get jwtValidationPubKeys(): string[];
    set jwtValidationPubKeys(value: string[]);
    resetJwtValidationPubKeys(): void;
    get jwtValidationPubKeysInput(): string[] | undefined;
    private _listClaimMappings?;
    get listClaimMappings(): {
        [key: string]: string;
    };
    set listClaimMappings(value: {
        [key: string]: string;
    });
    resetListClaimMappings(): void;
    get listClaimMappingsInput(): {
        [key: string]: string;
    } | undefined;
    private _notBeforeLeeway?;
    get notBeforeLeeway(): string;
    set notBeforeLeeway(value: string);
    resetNotBeforeLeeway(): void;
    get notBeforeLeewayInput(): string | undefined;
    private _oidcClientId?;
    get oidcClientId(): string;
    set oidcClientId(value: string);
    resetOidcClientId(): void;
    get oidcClientIdInput(): string | undefined;
    private _oidcClientSecret?;
    get oidcClientSecret(): string;
    set oidcClientSecret(value: string);
    resetOidcClientSecret(): void;
    get oidcClientSecretInput(): string | undefined;
    private _oidcDisableUserinfo?;
    get oidcDisableUserinfo(): boolean | cdktf.IResolvable;
    set oidcDisableUserinfo(value: boolean | cdktf.IResolvable);
    resetOidcDisableUserinfo(): void;
    get oidcDisableUserinfoInput(): boolean | cdktf.IResolvable | undefined;
    private _oidcDiscoveryUrl?;
    get oidcDiscoveryUrl(): string;
    set oidcDiscoveryUrl(value: string);
    resetOidcDiscoveryUrl(): void;
    get oidcDiscoveryUrlInput(): string | undefined;
    private _oidcEnablePkce?;
    get oidcEnablePkce(): boolean | cdktf.IResolvable;
    set oidcEnablePkce(value: boolean | cdktf.IResolvable);
    resetOidcEnablePkce(): void;
    get oidcEnablePkceInput(): boolean | cdktf.IResolvable | undefined;
    private _oidcScopes?;
    get oidcScopes(): string[];
    set oidcScopes(value: string[]);
    resetOidcScopes(): void;
    get oidcScopesInput(): string[] | undefined;
    private _signingAlgs?;
    get signingAlgs(): string[];
    set signingAlgs(value: string[]);
    resetSigningAlgs(): void;
    get signingAlgsInput(): string[] | undefined;
    private _verboseLogging?;
    get verboseLogging(): boolean | cdktf.IResolvable;
    set verboseLogging(value: boolean | cdktf.IResolvable);
    resetVerboseLogging(): void;
    get verboseLoggingInput(): boolean | cdktf.IResolvable | undefined;
    private _oidcClientAssertion;
    get oidcClientAssertion(): AclAuthMethodConfigOidcClientAssertionOutputReference;
    putOidcClientAssertion(value: AclAuthMethodConfigOidcClientAssertion): void;
    resetOidcClientAssertion(): void;
    get oidcClientAssertionInput(): AclAuthMethodConfigOidcClientAssertion | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method nomad_acl_auth_method}
*/
export declare class AclAuthMethod extends cdktf.TerraformResource {
    static readonly tfResourceType = "nomad_acl_auth_method";
    /**
    * Generates CDKTF code for importing a AclAuthMethod resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AclAuthMethod to import
    * @param importFromId The id of the existing AclAuthMethod that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AclAuthMethod to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/resources/acl_auth_method nomad_acl_auth_method} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AclAuthMethodConfig
    */
    constructor(scope: Construct, id: string, config: AclAuthMethodConfig);
    private _default?;
    get default(): boolean | cdktf.IResolvable;
    set default(value: boolean | cdktf.IResolvable);
    resetDefault(): void;
    get defaultInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxTokenTtl?;
    get maxTokenTtl(): string;
    set maxTokenTtl(value: string);
    get maxTokenTtlInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tokenLocality?;
    get tokenLocality(): string;
    set tokenLocality(value: string);
    get tokenLocalityInput(): string | undefined;
    private _tokenNameFormat?;
    get tokenNameFormat(): string;
    set tokenNameFormat(value: string);
    resetTokenNameFormat(): void;
    get tokenNameFormatInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _config;
    get config(): AclAuthMethodConfigAOutputReference;
    putConfig(value: AclAuthMethodConfigA): void;
    get configInput(): AclAuthMethodConfigA | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
