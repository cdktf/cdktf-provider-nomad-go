/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataNomadAclTokensConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/data-sources/acl_tokens#id DataNomadAclTokens#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/data-sources/acl_tokens#prefix DataNomadAclTokens#prefix}
    */
    readonly prefix?: string;
}
export interface DataNomadAclTokensAclTokensRoles {
}
export declare function dataNomadAclTokensAclTokensRolesToTerraform(struct?: DataNomadAclTokensAclTokensRoles): any;
export declare function dataNomadAclTokensAclTokensRolesToHclTerraform(struct?: DataNomadAclTokensAclTokensRoles): any;
export declare class DataNomadAclTokensAclTokensRolesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataNomadAclTokensAclTokensRoles | undefined;
    set internalValue(value: DataNomadAclTokensAclTokensRoles | undefined);
    get id(): string;
    get name(): string;
}
export declare class DataNomadAclTokensAclTokensRolesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataNomadAclTokensAclTokensRolesOutputReference;
}
export interface DataNomadAclTokensAclTokens {
}
export declare function dataNomadAclTokensAclTokensToTerraform(struct?: DataNomadAclTokensAclTokens): any;
export declare function dataNomadAclTokensAclTokensToHclTerraform(struct?: DataNomadAclTokensAclTokens): any;
export declare class DataNomadAclTokensAclTokensOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataNomadAclTokensAclTokens | undefined;
    set internalValue(value: DataNomadAclTokensAclTokens | undefined);
    get accessorId(): string;
    get createTime(): string;
    get expirationTime(): string;
    get global(): cdktf.IResolvable;
    get name(): string;
    get policies(): string[];
    private _roles;
    get roles(): DataNomadAclTokensAclTokensRolesList;
    get type(): string;
}
export declare class DataNomadAclTokensAclTokensList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataNomadAclTokensAclTokensOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/data-sources/acl_tokens nomad_acl_tokens}
*/
export declare class DataNomadAclTokens extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "nomad_acl_tokens";
    /**
    * Generates CDKTF code for importing a DataNomadAclTokens resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNomadAclTokens to import
    * @param importFromId The id of the existing DataNomadAclTokens that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/data-sources/acl_tokens#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNomadAclTokens to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.1/docs/data-sources/acl_tokens nomad_acl_tokens} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNomadAclTokensConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataNomadAclTokensConfig);
    private _aclTokens;
    get aclTokens(): DataNomadAclTokensAclTokensList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
