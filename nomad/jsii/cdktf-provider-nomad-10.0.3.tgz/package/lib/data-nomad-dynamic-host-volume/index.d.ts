/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataNomadDynamicHostVolumeConfig extends cdktf.TerraformMetaArguments {
    /**
    * Volume ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.2/docs/data-sources/dynamic_host_volume#id DataNomadDynamicHostVolume#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Volume namespace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.2/docs/data-sources/dynamic_host_volume#namespace DataNomadDynamicHostVolume#namespace}
    */
    readonly namespace?: string;
}
export interface DataNomadDynamicHostVolumeCapability {
}
export declare function dataNomadDynamicHostVolumeCapabilityToTerraform(struct?: DataNomadDynamicHostVolumeCapability): any;
export declare function dataNomadDynamicHostVolumeCapabilityToHclTerraform(struct?: DataNomadDynamicHostVolumeCapability): any;
export declare class DataNomadDynamicHostVolumeCapabilityOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataNomadDynamicHostVolumeCapability | undefined;
    set internalValue(value: DataNomadDynamicHostVolumeCapability | undefined);
    get accessMode(): string;
    get attachmentMode(): string;
}
export declare class DataNomadDynamicHostVolumeCapabilityList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataNomadDynamicHostVolumeCapabilityOutputReference;
}
export interface DataNomadDynamicHostVolumeConstraint {
}
export declare function dataNomadDynamicHostVolumeConstraintToTerraform(struct?: DataNomadDynamicHostVolumeConstraint): any;
export declare function dataNomadDynamicHostVolumeConstraintToHclTerraform(struct?: DataNomadDynamicHostVolumeConstraint): any;
export declare class DataNomadDynamicHostVolumeConstraintOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataNomadDynamicHostVolumeConstraint | undefined;
    set internalValue(value: DataNomadDynamicHostVolumeConstraint | undefined);
    get attribute(): string;
    get operator(): string;
    get value(): string;
}
export declare class DataNomadDynamicHostVolumeConstraintList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataNomadDynamicHostVolumeConstraintOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.2/docs/data-sources/dynamic_host_volume nomad_dynamic_host_volume}
*/
export declare class DataNomadDynamicHostVolume extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "nomad_dynamic_host_volume";
    /**
    * Generates CDKTF code for importing a DataNomadDynamicHostVolume resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNomadDynamicHostVolume to import
    * @param importFromId The id of the existing DataNomadDynamicHostVolume that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.2/docs/data-sources/dynamic_host_volume#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNomadDynamicHostVolume to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.2/docs/data-sources/dynamic_host_volume nomad_dynamic_host_volume} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNomadDynamicHostVolumeConfig
    */
    constructor(scope: Construct, id: string, config: DataNomadDynamicHostVolumeConfig);
    private _capability;
    get capability(): DataNomadDynamicHostVolumeCapabilityList;
    get capacity(): string;
    get capacityBytes(): number;
    get capacityMax(): string;
    get capacityMaxBytes(): number;
    get capacityMin(): string;
    get capacityMinBytes(): number;
    private _constraint;
    get constraint(): DataNomadDynamicHostVolumeConstraintList;
    get hostPath(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get name(): string;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get nodeId(): string;
    get nodePool(): string;
    private _parameters;
    get parameters(): cdktf.StringMap;
    get pluginId(): string;
    get state(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
