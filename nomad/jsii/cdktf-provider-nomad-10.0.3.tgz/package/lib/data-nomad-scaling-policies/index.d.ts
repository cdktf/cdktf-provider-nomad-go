/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataNomadScalingPoliciesConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.2/docs/data-sources/scaling_policies#id DataNomadScalingPolicies#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Job ID to use to filter scaling policies.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.2/docs/data-sources/scaling_policies#job_id DataNomadScalingPolicies#job_id}
    */
    readonly jobId?: string;
    /**
    * Scaling policy type used to filter scaling policies.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.2/docs/data-sources/scaling_policies#type DataNomadScalingPolicies#type}
    */
    readonly type?: string;
}
export interface DataNomadScalingPoliciesPolicies {
}
export declare function dataNomadScalingPoliciesPoliciesToTerraform(struct?: DataNomadScalingPoliciesPolicies): any;
export declare function dataNomadScalingPoliciesPoliciesToHclTerraform(struct?: DataNomadScalingPoliciesPolicies): any;
export declare class DataNomadScalingPoliciesPoliciesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataNomadScalingPoliciesPolicies | undefined;
    set internalValue(value: DataNomadScalingPoliciesPolicies | undefined);
    get enabled(): cdktf.IResolvable;
    get id(): string;
    private _target;
    get target(): cdktf.StringMap;
    get type(): string;
}
export declare class DataNomadScalingPoliciesPoliciesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataNomadScalingPoliciesPoliciesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.2/docs/data-sources/scaling_policies nomad_scaling_policies}
*/
export declare class DataNomadScalingPolicies extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "nomad_scaling_policies";
    /**
    * Generates CDKTF code for importing a DataNomadScalingPolicies resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNomadScalingPolicies to import
    * @param importFromId The id of the existing DataNomadScalingPolicies that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.2/docs/data-sources/scaling_policies#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNomadScalingPolicies to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/nomad/2.5.2/docs/data-sources/scaling_policies nomad_scaling_policies} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNomadScalingPoliciesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataNomadScalingPoliciesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _jobId?;
    get jobId(): string;
    set jobId(value: string);
    resetJobId(): void;
    get jobIdInput(): string | undefined;
    private _policies;
    get policies(): DataNomadScalingPoliciesPoliciesList;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
